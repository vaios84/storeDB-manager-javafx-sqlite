
package alertBox;

import javafx.application.Application;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.geometry.*;
import javafx.scene.control.Alert.AlertType;

public class AlertBox extends Application {
    
    // Static methods can be called without creating an object of this class AlertBox
    // You can write: AlertBox.display("Info Warning", " Ποσότητα Κάτω από 10")
    public static void display(String title, String message) {
        Stage window = new Stage();

        //Block events to other windows
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle(title);
        window.setHeight(100);
        window.setWidth(250);
        
        Label label = new Label();
        label.setText(message);
        Button closeButton = new Button(" OK ");
        closeButton.setOnAction(e -> window.close());

        VBox layout = new VBox(10);
        layout.getChildren().addAll(label, closeButton);
        layout.setAlignment(Pos.CENTER);

        //Display window and wait for it to be closed before returning
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }

        
    // Show a Warning Alert
    public void showQtyWarningAlert() {
        Alert alert = new Alert(AlertType.WARNING);
        alert.setTitle("Products Warning Alert");
        //alert.setHeaderText("Current Status:");
        // Header Text null
        alert.setHeaderText(null);
        alert.setContentText("Υπάρχουν προιόντα σε ποσότητα κάτω από 10 τεμάχια!"); 
        alert.showAndWait();
    }
    
    // Show a Warning Alert
    public void showQtyWarningAlert2() {
        Alert alert = new Alert(AlertType.WARNING);
        alert.setTitle("Products Warning Alert");
        //alert.setHeaderText("Current Status:");
        // Header Text null
        alert.setHeaderText(null);
        alert.setContentText("To προιόν έχει ποσότητα κάτω από 10 τεμάχια!"); 
        alert.showAndWait();
    }
    
    
    // Show a Information Alert with header Text
    public void showInfoAlert() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Products Info Alert");
        alert.setHeaderText("Προσθήκη Προιόντος");
        alert.setContentText("Το νέο προιόν σας προστέθηκε με επιτυχία!");
 
        alert.showAndWait();
    }
    
        // Show a Information Alert with header Text
    public void showInfoAlert2() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Products Info Alert");
        alert.setHeaderText("Διαγραφή Προιόντος");
        alert.setContentText("Το προιόν διαγράφηκε από την Βάση Δεδομένων!");
 
        alert.showAndWait();
    }
    
    
    @Override
    public void start(Stage stage) throws Exception {
        VBox alertroot = new VBox();
        alertroot.setPadding(new Insets(10));
        alertroot.setSpacing(10);
 
        Scene alertscene = new Scene(alertroot, 450, 250);
        stage.setTitle("JavaFX Warning Alert");
        stage.setScene(alertscene);
        
        showQtyWarningAlert();
        showQtyWarningAlert2();
        showInfoAlert();
        showInfoAlert2();
        
        stage.show();
        
    }


    
}
