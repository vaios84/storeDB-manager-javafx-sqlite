
package students;

import dbUtil.dbConnection;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Formatter;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import loginapp.option;

public class printDataFXMLController implements Initializable {
    
    @FXML
    private Button print1button;
    @FXML
    private Button print2button;
    @FXML
    private Button print3button;
    
    @FXML
    private ComboBox<option> combobox2;
    @FXML
    private ComboBox<option> combobox3;
    
    
    
    @FXML
    private Button gobackbutton;
    
    private ObservableList<ProductData> data;  
    private dbConnection dc;
    
    private static boolean flagAlertBox=true;
    
    private Formatter x;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.dc = new dbConnection();    
        
    }

    @FXML
    public void goback(ActionEvent event) {
        Stage stage = (Stage)this.gobackbutton.getScene().getWindow();
        stage.close();    
        
    }
    
    @FXML
    public void printLowQtyProducts(ActionEvent event) {
    
       
    }

    @FXML
    public void printCategory(ActionEvent event) {
        
    
    }

    @FXML
    public void printSupplier(ActionEvent event) {
        
    
    }



    
}
