
package students;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class ProductData {
    private final StringProperty pid;
    private final StringProperty pname;
    private final StringProperty price;
    private final StringProperty quantity;
    private final StringProperty category;
    private final StringProperty supplier;
    
    // Constructor
    public ProductData (String pid, String pname, String price, String quantity, String category, String supplier) {
          this.pid = new SimpleStringProperty(pid);
          this.pname = new SimpleStringProperty(pname);
          this.price = new SimpleStringProperty(price);
          this.quantity = new SimpleStringProperty(quantity);
          this.category = new SimpleStringProperty(category);
          this.supplier = new SimpleStringProperty(supplier);
      }
      
      // Getter methods
    public String getPid() {
        return (String)this.pid.get();
    }

    public String getPname() {
        return (String)this.pname.get();
    }

    public String getPrice() {
        return (String)this.price.get();
    }

    public String getQuantity() {
        return (String)this.quantity.get();
    }

    public String getCategory() {
        return (String)this.category.get();
    }

    public String getSupplier() {
        return (String)this.supplier.get();
    }
      
      // Setter methods    
    public void setPid(String value) {
        this.pid.set(value);
    }
    
    public void setPname(String value) {
        this.pname.set(value);
    }      
    
    public void setPrice(String value) {
        this.price.set(value);
    }
      
    public void setQuantity(String value) {
        this.quantity.set(value);
    }
    
    public void setCategory(String value) {
        this.category.set(value);
    }
    
    public void setSupplier(String value) {
        this.supplier.set(value);
    }
    
    // Getter methods for String Properties
    public StringProperty pidProperty() {
        return this.pid;
    }
    
    public StringProperty pnameProperty() {
        return this.pname;
    }
    
    public StringProperty priceProperty() {
        return this.price;
    }
    
    public StringProperty quantityProperty() {
        return this.quantity;
    }
    
    public StringProperty categoryProperty() {
        return this.category;
    }
    
    public StringProperty supplierProperty() { return this.supplier; }
    
    
}
