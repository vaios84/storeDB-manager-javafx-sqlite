package students;

import alertBox.AlertBox;
import dbUtil.dbConnection;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class StudentsFXMLController implements Initializable {
  
  @FXML
  private TextField id;
  @FXML
  private TextField pname;
  @FXML
  private TextField price;
  @FXML
  private TextField qty;
  @FXML
  private TextField category;
  @FXML
  private TextField supplier;
  @FXML
  private TableView<ProductData> producttable;
  @FXML
  private TableColumn<ProductData, String> idcolumn;
  @FXML
  private TableColumn<ProductData, String> pnamecolumn;
  @FXML
  private TableColumn<ProductData, Double> pricecolumn;
  @FXML
  private TableColumn<ProductData, Integer> qtycolumn;
  @FXML
  private TableColumn<ProductData, String> catcolumn;
  @FXML
  private TableColumn<ProductData, String> scolumn;
  @FXML
  private Button findbutton;
  @FXML
  private Button loadbutton;
  @FXML
  private Button productMinusOne;
  @FXML
  private Button productPlusOne;
  @FXML
  private Button productPlusTen;
  @FXML
  private Button addbutton;
  @FXML
  private Button removebutton;
  @FXML
  private Button clearbutton;
  @FXML
  private Button printbutton;
  
  
  private ObservableList<ProductData> data;  
  private dbConnection dc;
  
  private static boolean flagAlertBox=true;
  
  @Override
  public void initialize(URL url, ResourceBundle rb) {
      this.dc = new dbConnection();
  }
  
  @FXML
  private void loadProductData(ActionEvent event){
      
      try{
            Connection conn = dbConnection.getConnection();
            this.data = FXCollections.observableArrayList();
      
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM products");
            while (rs.next()) {
                this.data.add(new ProductData(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6)));
            }
            
            
            conn.close();
            
      } catch(SQLException e){
          System.err.println("Error " + e);   
      }
  
      this.idcolumn.setCellValueFactory(new PropertyValueFactory("pid"));
      this.pnamecolumn.setCellValueFactory(new PropertyValueFactory("pname"));
      this.pricecolumn.setCellValueFactory(new PropertyValueFactory("price"));
      this.qtycolumn.setCellValueFactory(new PropertyValueFactory("quantity"));
      this.catcolumn.setCellValueFactory(new PropertyValueFactory("category"));
      this.scolumn.setCellValueFactory(new PropertyValueFactory("supplier"));
      
      this.producttable.setItems(null);
      this.producttable.setItems(this.data);
      
      // handle the alert box appearance or not     
      try {
          Connection conn = dbConnection.getConnection();
          ResultSet rs2 = conn.createStatement().executeQuery("SELECT min(quantity) FROM products");
          int qtylimit = rs2.getInt(1);
                    
          if(flagAlertBox==true && qtylimit<10) { 
            AlertBox ob1 = new AlertBox();
            ob1.showQtyWarningAlert();  
             
            flagAlertBox=false;  // flag needs in order to show the alert only one time, not every time loadProductData is called 
            
          } 
      
          conn.close();
      } catch (SQLException e) {
          System.err.println("Error " + e);
      
      }   
      
  } 
  
  @FXML
  private void findProduct(ActionEvent event) {
      try{
            Connection conn = dbConnection.getConnection();
            this.data = FXCollections.observableArrayList();
            
            String searchProduct = this.id.getText();
            
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM products WHERE productID= " + searchProduct);
            
            while (rs.next()) {
                this.data.add(new ProductData(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6)));
            }
            
            conn.close();
      
      } catch(SQLException e){
          System.err.println("Error " + e);   
      }
  
      this.idcolumn.setCellValueFactory(new PropertyValueFactory("pid"));
      this.pnamecolumn.setCellValueFactory(new PropertyValueFactory("pname"));
      this.pricecolumn.setCellValueFactory(new PropertyValueFactory("price"));
      this.qtycolumn.setCellValueFactory(new PropertyValueFactory("quantity"));
      this.catcolumn.setCellValueFactory(new PropertyValueFactory("category"));
      this.scolumn.setCellValueFactory(new PropertyValueFactory("supplier"));
      
      this.producttable.setItems(null);
      this.producttable.setItems(this.data);
      
  }
  
  @FXML
  private void addProduct(ActionEvent event){
    
    String sql = "INSERT INTO `products`(`productID`, `productName`, `price`, `quantity`, `category`, `supplier`) VALUES (?, ?, ?, ?, ?, ?)";
    try {
      Connection conn = dbConnection.getConnection();
      PreparedStatement stmt = conn.prepareStatement(sql);
      stmt.setString(1, this.id.getText());
      stmt.setString(2, this.pname.getText());
      stmt.setString(3, this.price.getText());
      stmt.setString(4, this.qty.getText());
      stmt.setString(5, this.category.getText());
      stmt.setString(6, this.supplier.getText());
      
      // check that no items with blank id are inserted in my db
      if(this.id.getText().length() !=0) {
        stmt.execute();      
        loadProductData(event); // call this method to refresh the table's data  
        
        // write action to log file
        String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
        logWriteFunction("Process Executed: Remove Product. "+"Product ID= " + this.id.getText() + ". Product Name = " + this.pname.getText() + ". Time= " + timeStamp);
                
        //show the alert
        AlertBox ob1 = new AlertBox();
        ob1.showInfoAlert(); 
      }
      
      
      conn.close();
      
    } catch (SQLException e) {
      System.err.println("Got an exception!");
      System.err.println(e.getMessage());
    }
    
    
  
  }

  @FXML
  private void removeProduct(ActionEvent event){
      String sql = "DELETE FROM `products` WHERE productID=? "; 
      try{
          Connection conn = dbConnection.getConnection();
          
          // need the product name for the write action to log file 
          ResultSet rs = conn.createStatement().executeQuery("SELECT productName FROM products WHERE productID=" + this.id.getText());
          String productname = rs.getString(1);
          
          // then delete the product
          PreparedStatement stmt = conn.prepareStatement(sql);
          stmt.setString(1, this.id.getText());
          
          if(this.id.getText().length() !=0) {
                stmt.execute();
      
                loadProductData(event); // call this method to refresh the table's data
                
                // write action to log file          
                String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
                logWriteFunction("Process Executed: Remove Product. "+"Product ID= " + this.id.getText() + ". Product Name = " + productname+ ". Time= " + timeStamp);
                
                // show the alert
                AlertBox ob1 = new AlertBox();
                ob1.showInfoAlert2();
                
                
          }
          
          conn.close();
      
      } catch (SQLException e) {
          System.err.println("Got an exception!");
          System.err.println(e.getMessage());
      
      }
      
  
  
  }

  @FXML
  private void clearFields(ActionEvent event) { 
    
    this.id.setText("");
    this.pname.setText("");
    this.price.setText("");
    this.qty.setText("");
    this.category.setText("");
    this.supplier.setText("");
    
  }
  
  
  @FXML
  private void plusOneProduct(ActionEvent event){
      
    String sql = "UPDATE `products` SET quantity=quantity+1 WHERE productID=?";
    try {
      Connection conn = dbConnection.getConnection();
      PreparedStatement stmt = conn.prepareStatement(sql);
      stmt.setString(1, this.id.getText());
      stmt.execute();
      
      findProduct(event); // call this method to refresh the table's data
      
      // write action to log file
      ResultSet rs = conn.createStatement().executeQuery("SELECT quantity FROM products WHERE productID=" + this.id.getText());
      int qty = rs.getInt(1);
      String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
      logWriteFunction("Process Executed: Plus One Item. "+"Product ID= " + this.id.getText() + ". New quantity = " + qty+ ". Time= " + timeStamp);
      
      conn.close();
    } catch (SQLException e) {
      System.err.println("Got an exception!");
      System.err.println(e.getMessage());
    }
  
  }
  
    
  @FXML
  private void plusTenProduct(ActionEvent event){
    String sql = "UPDATE `products` SET quantity=quantity+10 WHERE productID=?";
    try {
      Connection conn = dbConnection.getConnection();
      PreparedStatement stmt = conn.prepareStatement(sql);
      stmt.setString(1, this.id.getText());
      stmt.execute();
      
      findProduct(event); // call this method to refresh the table's data
      
      // write action to log file
      ResultSet rs = conn.createStatement().executeQuery("SELECT quantity FROM products WHERE productID=" + this.id.getText());
      int qty = rs.getInt(1);
      String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
      logWriteFunction("Process Executed: Minus One Item. "+"Product ID= " + this.id.getText() + ". New quantity = " + qty+ ". Time= " + timeStamp);
      
      conn.close();
      
    } catch (SQLException e) {
      System.err.println("Got an exception!");
      System.err.println(e.getMessage());
    }
  
  }
  
  
    
  @FXML
  private void minusOneProduct(ActionEvent event){
    int qtylimit=0;
    
    // find the quantity of the product that we want to sell and so remove one iten from quantity
    try{
        Connection conn = dbConnection.getConnection();
        ResultSet rs = conn.createStatement().executeQuery("SELECT quantity FROM products WHERE productID=" + this.id.getText());
        qtylimit = rs.getInt(1); 
        
        conn.close();
    
    } catch(SQLException e){
        System.err.println("Got an exception!");
        System.err.println(e.getMessage());
    
    }
    
    // if quantity is not over zero it should not be reduced more
    if(qtylimit>0)  {
        
        String sql = "UPDATE `products` SET quantity=quantity-1 WHERE productID=?";
        try {
            Connection conn = dbConnection.getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, this.id.getText());
            stmt.execute();
      
            findProduct(event); // call this method to refresh the table's data
      
            // handle the alert box appearance. if the new reduced qty has gone under 10.
            ResultSet rs2 = conn.createStatement().executeQuery("SELECT quantity FROM products WHERE productID=" + this.id.getText());
            qtylimit = rs2.getInt(1);
                    
            if(qtylimit==9) { // to show the alert only when qty goes below 10 for first time and not sgow it again for qty = 8,7,6... 
                
                AlertBox ob1 = new AlertBox();
                ob1.showQtyWarningAlert2();
                
                flagAlertBox=false;  //flag needs in order to show the alert only one time, not every time loadProductData is called 
            }
            
            // write action to log file
            String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
            logWriteFunction("Process Executed: Minus One Item. "+"Product ID= " + this.id.getText() + ". New quantity = " + qtylimit+ ". Time= " + timeStamp);
            
            conn.close();
      
        } catch (SQLException e) {
            System.err.println("Got an exception!");
            System.err.println(e.getMessage());
        }
        
    }
    
  }
  
  @FXML
  private void printDataForms(ActionEvent event) {
    try {
      Stage dataStage = new Stage();
      FXMLLoader loader = new FXMLLoader();
      Pane datapane = (Pane)loader.load(getClass().getResource("/students/printDataFXML.fxml").openStream());
      
      Scene datascene = new Scene(datapane);
      
      dataStage.initModality(Modality.APPLICATION_MODAL);  //Block events to other windows
      dataStage.setScene(datascene);
      dataStage.setTitle("Print Data Forms");
      dataStage.setResizable(false);
      dataStage.showAndWait(); //Display window and wait for it to be closed before returning
    } catch (IOException e) {
      e.printStackTrace();
      
    }
    
  }
  
  // this function will be used, inside other functions of this class, to log the actions done on the database (insert, update, delete)
  private void logWriteFunction(String mydata) {
       BufferedWriter bw = null;
       
       try {
           bw = new BufferedWriter(new FileWriter(new File("logfile.txt"), true)); 
           bw.write(mydata+"\n");
           System.out.println("Write Done!");
       
       } 
       catch (FileNotFoundException exx) {
           exx.printStackTrace();
       
       }   
       catch (IOException ex) {
            Logger.getLogger(printDataFXMLController.class.getName()).log(Level.SEVERE, null, ex);
       }
       
        try {
            bw.close();
        } catch (IOException ex) {
            Logger.getLogger(printDataFXMLController.class.getName()).log(Level.SEVERE, null, ex);
        }
  
  }
  
  
  @FXML
  private void logReadFunction() {
       
  
  
  }
  
  
}